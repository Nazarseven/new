import React from "react"
import ContentLoader from "react-content-loader"

const Skeleton = (props) => (
    <ContentLoader 
    speed={2}
    width={225}
    height={410}
    viewBox="0 0 225 410"
    backgroundColor="#f3f3f3"
    foregroundColor="#ecebeb"
    {...props}
  >
    <rect x="0" y="225" rx="0" ry="0" width="220" height="23" /> 
    <circle cx="111" cy="111" r="111" /> 
    <rect x="-1" y="254" rx="0" ry="0" width="220" height="61" /> 
    <rect x="0" y="325" rx="0" ry="0" width="105" height="27" /> 
    <rect x="114" y="325" rx="16" ry="16" width="107" height="27" />
  </ContentLoader>
)

export default Skeleton