import Pizza from "./pizza";

export default Pizza