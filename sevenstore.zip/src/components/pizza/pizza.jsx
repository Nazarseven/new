import React from 'react'
import { useState } from "react";

const Pizza = ({title, price, imageUrl, sizes, types}) => {

    const [activeType, setActiveType] = useState(0)
    const [activeSize, setActiveSize] = useState(0)

    const typeNames = ['тонкое', 'традиционное']

    return (
        <div className="col">
            <img src={imageUrl} alt="" />
            <h3>{title} пицца</h3>
            <div className="select">
                <div className="first-ul row">
                    {types.map((elem) => (
                        <h5 key={elem} onClick={() => setActiveType(elem)} className={activeType === elem ? 'active' : ''}>{typeNames[elem]}</h5>
                    ))}
                </div>
                <div className="second-ul row">
                    {sizes.map((elem, i) => (
                        <h5 key={elem} onClick={() => setActiveSize(i)} className={activeSize === i ? 'active' : ''}>{elem} см.</h5>
                    ))}
                </div>
            </div>
            <div className="row">
                <h4>от {price} м</h4>
                <button >
                    <img src="img/plus.svg" alt="" />
                    <p>Добавить <span>0</span></p>
                </button>
            </div>
        </div>
    )
}

export default Pizza