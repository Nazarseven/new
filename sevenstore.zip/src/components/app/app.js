import React from "react";
import { Route, Routes } from "react-router-dom";


import "./app.css"
import "./style.scss"

import Header from "../header";
import Home from "../../pages/home";
import NotFound from "../../pages/notFound";
import Cart from "../../pages/cart";


const App = () => {

    const [searchValue, setSearchValue] = React.useState('')
        console.log(searchValue, 'INPUT CHANGED')
    return (
        <>
        <div className="background">
            <Header searchValue={searchValue} setSearchValue={setSearchValue}/>
            <hr className="horizontal" />
            <Routes>
                <Route path='/' element={<Home searchValue={searchValue}/>} />
                <Route path='/cart' element={<Cart />} />
                <Route path='*' element={<NotFound />} />
            </Routes>
        </div>
        </>
    )
}

export default App