import React from 'react'

import styles from './Pagination.module.scss'

export const Pagination = () => {
  return (
    
  )
}


export default Pagination