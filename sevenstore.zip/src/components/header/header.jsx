import React from "react";
import { Link } from "react-router-dom";
import Search from "../app/search";

const Header = ({ searchValue, setSearchValue }) => {
    return (
        <header id="header">
            <div className="container">
                <div className="row">
                    <Link to="/">
                    <div className="row2">
                            <img src="img/logo.svg" className="logo" alt="" />
                            <div>
                                <h1>Seven Pizza</h1>
                                <p>самая вкусная пицца во вселенной</p>
                            </div>
                    </div>
                    </Link>
                    <Search searchValue={searchValue} setSearchValue={setSearchValue} />
                    <div className="header-right">
                        <Link to="cart">
                        <button>
                            <div>
                                <h5>520 m</h5>
                            </div>
                            <div className="row2">
                                <img src="img/cart.svg" alt="" />
                                <h5>3</h5>
                            </div>
                        </button>
                        </Link>
                    </div>
                </div>
            </div>
        </header>
    )
}

export default Header