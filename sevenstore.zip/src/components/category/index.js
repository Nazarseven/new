import Category from "./category";

export default Category