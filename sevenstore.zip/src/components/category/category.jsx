import React from "react";

const Category = ({ value, onClickCategory }) => {
    console.log(value)
    const categories = [
        'Все',
        'Мясные',
        'Вегатарианская',
        'Гриль',
        'Острые',
        'Закрытые'
    ]


    return (
        <div className="col2">
            <ul>
                {categories.map((elem, index) => (
                    <li 
                        key={index} 
                        onClick={() => onClickCategory(index)} 
                        className={value === index ? 'active' :
                        ''}>{elem}</li>
                ))}
            </ul>
        </div>
    )
}

export default Category