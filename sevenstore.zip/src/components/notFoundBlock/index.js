import NotFoundBlock from "./notFoundBlock";

export default NotFoundBlock