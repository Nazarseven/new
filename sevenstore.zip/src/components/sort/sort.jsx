import React from "react";

const Sort = ({ sortValue, onClickSort }) => {

    const [open, setOpen] = React.useState(false)

    const sort = [
        { name: "Популярности (DESK)", sortProperty: 'rating' }, 
        { name: "Популярности (ASC", sortProperty: '-rating' }, 
        { name: "Цене (DESK)", sortProperty: 'price' }, 
        { name: "Цене (ASC", sortProperty: '-price' }, 
        { name: "Алфавиту (DESK)", sortProperty: 'title' },
        { name: "Алфавиту (ASC", sortProperty: '-title' }
    ]

    const onClickList = (i) => {
        onClickSort(i)
        setOpen(false)
    }

    return (
        <div className="col2">
            <h4>Сортировка по:  <span onClick={() => setOpen(!open)}>{sortValue.name}</span></h4>
            {
                open && (<div className="sort-popup">
                <ul>
                    {sort.map((obj, index) => (
                        <li key={index} onClick={() => onClickList(obj)} className={sortValue.sortProperty === obj.sortProperty ? 'active' : ""}>{obj.name}</li>
                    ))}
                </ul>
            </div>)
            }
        </div>
    )
}

export default Sort