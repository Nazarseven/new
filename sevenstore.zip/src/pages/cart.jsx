import React from 'react'

import styles from './Cart.module.scss'


export const Cart= () => {
  return (
    <div className={styles.container}>
        <div className={styles.row}>
          <h1>Корзина</h1>
          <h4>Очистить корзину</h4>
        </div>
        <div className={styles.row2}>
          <div className={styles.row4}>
            <div className={styles.row3}>
              <img src="img/pizza-2.png" alt="" />
              <div>
                <h3>Сырный цепленок</h3>
                <p>Тонкое тесто, 26см</p>
              </div>
            </div>
            <div className={styles.row3}>
              <button>-</button>
                <h5>2</h5>
              <button>+</button>
            </div>
            <h3>77 TMT</h3>
            <button className={styles.xbutton}>X</button>
          </div>
          <div className={styles.row4}>
            <div className={styles.row3}>
              <img src="img/pizza-2.png" alt="" />
              <div>
                <h3>Сырный цепленок</h3>
                <p>Тонкое тесто, 26см</p>
              </div>
            </div>
            <div className={styles.row3}>
              <button>-</button>
                <h5>2</h5>
              <button>+</button>
            </div>
            <h3>77 TMT</h3>
            <button className={styles.xbutton}>X</button>
          </div>
          <div className={styles.row4}>
            <div className={styles.row3}>
              <img src="img/pizza-2.png" alt="" />
              <div>
                <h3>Сырный цепленок</h3>
                <p>Тонкое тесто, 26см</p>
              </div>
            </div>
            <div className={styles.row3}>
              <button>-</button>
                <h5>2</h5>
              <button>+</button>
            </div>
            <h3>77 TMT</h3>
            <button className={styles.xbutton}>X</button>
          </div>
          <div className={styles.row4}>
            <div className={styles.row3}>
              <img src="img/pizza-2.png" alt="" />
              <div>
                <h3>Сырный цепленок</h3>
                <p>Тонкое тесто, 26см</p>
              </div>
            </div>
            <div className={styles.row3}>
              <button>-</button>
                <h5>2</h5>
              <button>+</button>
            </div>
            <h3>77 TMT</h3>
            <button className={styles.xbutton}>X</button>
          </div>
        </div>
    </div>
  )
}

export default Cart