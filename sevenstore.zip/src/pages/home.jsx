import React from 'react'

import Category from '../components/category/category';
import Sort from '../components/sort/sort';
import Pizza from '../components/pizza/pizza';
import Skeleton from '../components/pizza/skeleton';
import ReactPaginate from 'react-paginate'

import pizzas from '../components/assets/pizzas.json'


export const Home = ({ searchValue }) => {

    const [items, setItems] = React.useState([])
    const [isLoaded, setIsLoaded] = React.useState(true)
    const [categoryId, setCategoryId] = React.useState(0)
    const [sort, setSort] = React.useState({ 
        name: "Популярности", 
        sortProperty: 'rating' 
    }
    )

    React.useEffect(() => {
        setIsLoaded(true)

        const order = sort.sortProperty.includes('-') ? 'asc' : 'desc'
        const replace = sort.sortProperty.replace('-', '')
        const category = categoryId > 0 ? `category=${categoryId}` : ''
        const search = searchValue ? `&search=${searchValue}` : ''

        fetch(`https://63627aae37f2167d6f658137.mockapi.io/items?${ 
            category}&sortBy=${replace}&order=${order}${search}`
            )
        .then(res => res.json())
        .then((arr) => {
            setItems(arr)
            setIsLoaded(false)
        })
    }, [categoryId, sort, searchValue])


    const pizza = items.map((elem) => (<Pizza key={elem.id} {...elem}/>))

  return (
    <>
        <section id="section1">
            <div className="container">
                <div className="row">
                    <Category value={categoryId} onClickCategory={(index) => setCategoryId(index)}/>
                    <Sort sortValue={sort} onClickSort={(index) => setSort(index)}/>
                </div>
            </div>
            </section>
            <div id="section2">
            <div className="container">
                <h2>Все пиццы</h2>
                <div className="row-main">
                    {
                        isLoaded ? [...new Array(4)].map((_, index) => <Skeleton key={index}/>)
                        : pizza
                    }
                    {/* {
                        items.map((elem) => isLoaded ? <Skeleton /> : (
                            <Pizza key={elem.id} {...elem}/>
                        ))
                    } */}
                </div>
            </div>
            </div>
    </>
  )
}

export default Home