import React from 'react'

import NotFoundBlock from '../components/notFoundBlock/notFoundBlock'

export const NotFound = () => {
  return (
    <>
        <NotFoundBlock />
    </>
  )
}

export default NotFound